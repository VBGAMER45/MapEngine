//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MapEditor.rc
//
#define IDC_MYICON                      2
#define IDD_MAPEDITOR_DIALOG            102
#define IDD_ABOUTBOX                    103
#define IDS_APP_TITLE                   103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDS_HELLO                       106
#define IDI_MAPEDITOR                   107
#define IDI_SMALL                       108
#define IDC_MAPEDITOR                   109
#define IDR_MAINFRAME                   128
#define IDD_NEWMAP                      129
#define IDD_TOOLS                       133
#define IDC_TXTWIDTH                    1000
#define IDC_HIEGHT                      1001
#define IDC_TXTHEIGHT                   1002
#define IDC_WEBSITE                     1003
#define IDC_TXTY                        1004
#define IDC_TXTX                        1005
#define IDC_OPTCUSTOM                   1006
#define IDC_OPTHUGE                     1007
#define IDC_OPTEXTRALARGE               1008
#define IDC_OPTLARGE                    1009
#define IDC_OPTMEDIUM                   1010
#define IDC_OPTSMALL                    1011
#define IDC_OPTTINY                     1012
#define IDC_TXTMAPNAME                  1013
#define IDC_OK                          1014
#define IDC_CANCEL                      1015
#define IDC_CBOTILETYPE                 1016
#define IDC_LBLSELECTEDTOOL             1017
#define IDC_PICSELECTED                 1018
#define IDC_PICDISPLAY                  1019
#define IDC_TILEX                       1020
#define IDC_TILEY                       1021
#define IDC_PICMINIMAP                  1022
#define IDC_HSTILES                     1023
#define IDC_COMBO1                      1024
#define IDM_FILENEW                     32771
#define IDM_FILEOPEN                    32772
#define IDM_FILESAVE                    32773
#define IDM_MAPCLEARSCREEN              32775
#define IDM_MAPFILLSCREEN               32776
#define IDM_MAPVIEWFILETYPE             32777
#define IDC_TOOLSNORMALPAINT            32778
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32779
#define _APS_NEXT_CONTROL_VALUE         1025
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
