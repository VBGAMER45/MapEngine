========================================================================
       MapEditor by vbgamer45
	   Version 1.0
	   http://www.visualbasiczone.com
	   http://www.tileengines.com
========================================================================

Table of Contents:

1.  Introduction
2.  File List
3.  Contact

1.Introduction

2. File List


MapEditor.cpp
    This is the main application source file.

MapEditor.dsp
    This file (the project file) contains information at the project level and
    is used to build a single project or subproject. Other users can share the
    project (.dsp) file, but they should export the makefiles locally.
	

MapEditor.rc
    This is a listing of all of the Microsoft Windows resources that the
    program uses.  It includes the icons, bitmaps, and cursors that are stored
    in the RES subdirectory.  This file can be directly edited in Microsoft
	Visual C++.

res\MapEditor.ico
    This is an icon file, which is used as the application's icon (32x32).
    This icon is included by the main resource file MapEditor.rc.

small.ico
    %%This is an icon file, which contains a smaller version (16x16)
	of the application's icon. This icon is included by the main resource
	file MapEditor.rc.


StdAfx.h, StdAfx.cpp
    These files are used to build a precompiled header (PCH) file
    named MapEditor.pch and a precompiled types file named StdAfx.obj.

Resource.h
    This is the standard header file, which defines new resource IDs.
    Microsoft Visual C++ reads and updates this file.

3. Contact
   webmaster@visualbasiczone.com